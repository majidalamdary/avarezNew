package com.sputa.avarez.model;

//
public class item_ghabz_gas_detail
{


}
